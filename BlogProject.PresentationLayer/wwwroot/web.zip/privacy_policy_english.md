# Privacy Policy

*Last updated: 06-08-2025*

## 1. General Information

This privacy policy explains how personal data is collected, used, and protected when using the services provided by https://pasha.org.tr/ ("Site", "Service"). The Site is personally managed by Hasan Yasin Yaşar.

By using our Service, you agree to this privacy policy.

## 2. Information We Collect

### 2.1 Automatically Collected Information
- **IP Address**: Temporarily for rate limiting purposes
- **Cloudflare Traffic Data**: Traffic statistics automatically logged through Cloudflare infrastructure

### 2.2 User Account Information
Our service does not require any user account system. We do not request any personal information (name, email, phone, etc.).

### 2.3 Cookies
Our service does not use any cookies.

## 3. Data We Provide

Our service provides the following public network information:
- IP address information
- Netname information
- Country information
- Port information
- Service information
- Software Name information
- Software Version information
- Port number information
- HTTP headers information

**Important**: All this information is obtained from public network scan results and does not constitute personal data.

## 4. Data Usage Purposes

### 4.1 IP Address Usage
- **Purpose**: Rate limiting
- **Storage Duration**: Temporarily stored in cache and automatically deleted
- **Sharing**: Not shared with third parties

### 4.2 Cloudflare Traffic Data
- **Purpose**: Service performance and security
- **Control**: Subject to Cloudflare's own privacy policy
- **Details**: [Cloudflare Privacy Policy](https://www.cloudflare.com/privacypolicy/)

## 5. Data Security

- IP addresses are only temporarily stored for rate limiting
- No permanent user data is stored
- All data is processed on secure servers
- Site is personally managed with security measures in place
- Additional security layers provided through Cloudflare infrastructure

## 6. Third-Party Services

### 6.1 Cloudflare
Our service uses Cloudflare infrastructure. Cloudflare's own privacy policy applies:
- [Cloudflare Privacy Policy](https://www.cloudflare.com/privacypolicy/)

## 7. Legal Basis (GDPR Compliance)

Under the EU General Data Protection Regulation (GDPR):
- **Legitimate Interest**: Processing IP addresses for rate limiting
- **Public Interest**: Providing public network information

## 8. User Rights

Under GDPR and applicable data protection laws, your rights include:
- **Right to Information**: Learn what data is being processed
- **Right to Rectification**: Request correction of incorrect data
- **Right to Erasure**: Request deletion of your data
- **Right to Object**: Object to data processing

**Note**: Our service adopts a minimal data collection approach and most data is stored temporarily.

## 9. Data Retention Periods

- **IP Addresses**: Temporarily stored in rate limiting cache, automatically deleted
- **Cloudflare Data**: Subject to Cloudflare's data retention policy
- **Other Personal Data**: No personal data is stored

## 10. Children's Privacy

Our service is not directed to children under 13. We do not knowingly collect personal information from children under 13.

## 11. International Data Transfer

Data may be processed through Cloudflare's global infrastructure. Cloudflare takes necessary security measures for data transfers.

## 12. Policy Changes

We may update this privacy policy when necessary. Significant changes will be announced on the website.

## 13. Contact

For questions about this privacy policy:
- **Email**: yasin@pasha.org.tr
- **Data Controller**: Hasan Yasin Yaşar

---

**GDPR Notice**: This policy is prepared in accordance with the European Union General Data Protection Regulation.

**Local Law Notice**: This policy complies with applicable local data protection laws.