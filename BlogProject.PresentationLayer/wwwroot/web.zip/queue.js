const axios = require('axios');

// --- Configuration ---
const PYTHON_API_URL = process.env.PYTHON_API_URL || 'http://127.0.0.1:8000/run-all/';
const MAX_QUEUE_SIZE = 100; // Maximum number of IPs to hold in the queue

// --- State ---
const requestQueue = []; // Holds IP addresses to be processed
const scanStatus = {}; // Stores the status and result of each scan
let isProcessing = false; // Flag to ensure only one request is processed at a time

// --- Private Functions ---

/**
 * Processes the next IP in the queue.
 * This function is the core of the sequential processing logic.
 */
async function processQueue() {
    if (requestQueue.length === 0) {
        isProcessing = false;
        console.log('🔵 Queue is empty. Processor is going to sleep.');
        return;
    }

    isProcessing = true;
    const ip = requestQueue.shift(); // Get the next IP from the front of the queue

    console.log(`🚀 Processing scan for IP: ${ip}`);
    scanStatus[ip] = { status: 'processing', startTime: new Date() };

    try {
        console.log(`📡 Sending request to Python API for IP: ${ip}`);
        const response = await axios.post(PYTHON_API_URL, { ip_address: ip }, {
            timeout: 900000 // 15 minutes timeout for the Python script to run
        });

        const resultData = response.data;
        console.log(`✅ Successfully received data for IP ${ip}: ${JSON.stringify(resultData)}`);

        // Check for "false" response from Python API
        if (resultData === "false" || (typeof resultData === 'object' && resultData.status === 'false')) {
            scanStatus[ip] = {
                status: 'error',
                endTime: new Date(),
                error: 'IP üzerinde açık port bulunamadı.', // Specific message as requested
            };
        } else if (typeof resultData === 'string' && resultData.endsWith('pasha.org.tr/')) {
             // Check if the URL is the fallback one, indicating a potential failure in the script
             scanStatus[ip] = {
                status: 'error',
                endTime: new Date(),
                error: 'Scan script finished but returned a fallback URL, indicating an internal error or no result found.',
                url: resultData
            };
        } else {
            scanStatus[ip] = {
                status: 'complete',
                endTime: new Date(),
                url: resultData // Assuming resultData is the URL
            };
        }

    } catch (error) {
        const errorMessage = error.response ? JSON.stringify(error.response.data) : error.message;
        console.error(`❌ Error processing scan for IP ${ip}: ${errorMessage}`);
        scanStatus[ip] = {
            status: 'error',
            endTime: new Date(),
            error: `Failed to get a response from the Python API. Details: ${errorMessage}`
        };
    } finally {
        // Process the next item in the queue recursively
        processQueue();
    }
}

// --- Public Functions ---

/**
 * Adds an IP address to the scan queue.
 * @param {string} ip - The IP address to be scanned.
 * @returns {{success: boolean, message: string, status: string}} - The result of the operation.
 */
function addToQueue(ip) {
    if (!ip || typeof ip !== 'string' || !/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(ip)) {
        return { success: false, message: 'Invalid IP address format provided.', status: 'error' };
    }

    if (requestQueue.length >= MAX_QUEUE_SIZE) {
        console.warn(`⚠️ Queue is full. Rejecting new request for IP: ${ip}`);
        return { success: false, message: 'The scan queue is currently full. Please try again later.', status: 'full' };
    }
    
    // Check if the IP is already being processed or is in the queue
    if (scanStatus[ip]?.status === 'processing' || scanStatus[ip]?.status === 'queued') {
        console.log(`ℹ️ IP ${ip} is already in the queue or being processed.`);
        return { success: true, message: 'This IP is already in the queue.', status: scanStatus[ip].status };
    }

    // Add to queue and status map
    requestQueue.push(ip);
    scanStatus[ip] = { status: 'queued', queueTime: new Date() };
    console.log(`➕ IP ${ip} added to the queue. Current queue size: ${requestQueue.length}`);

    // If the processor is not running, start it.
    if (!isProcessing) {
        console.log('🟢 Processor is idle. Waking it up.');
        processQueue();
    }

    return { success: true, message: 'IP has been successfully added to the scan queue.', status: 'queued' };
}

/**
 * Retrieves the status of a specific scan.
 * @param {string} ip - The IP address to check.
 * @returns {object | null} - The status object or null if not found.
 */
function getStatus(ip) {
    return scanStatus[ip] || null;
}

/**
 * Retrieves the status of all items currently tracked.
 * @returns {object} - An object containing all scan statuses.
 */
function getAllStatuses() {
    return scanStatus;
}

/**
 * Retrieves the current queue.
 * @returns {Array<string>}
 */
function getQueue() {
    return requestQueue;
}

module.exports = {
    addToQueue,
    getStatus,
    getAllStatuses,
    getQueue
};
