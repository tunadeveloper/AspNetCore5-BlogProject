


console.log("Sunucu yeniden başlatılıyor...");
process.exit(0); 
