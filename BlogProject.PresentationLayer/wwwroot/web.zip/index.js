const express = require("express");
const expressLayouts = require('express-ejs-layouts');
const { MongoClient, ObjectId } = require("mongodb");
const path = require("path");
const cors = require("cors");
const helmet = require("helmet");
const apiRoutes = require("./api");
const queue = require('./queue'); // Import the queue module

const app = express();
const port = 3000;

// EJS and Layouts Setup
app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('layout', 'layout'); // sets /views/layout.ejs as the default layout

// Middleware
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
        imgSrc: ["'self'", "data:", "https://cdn.jsdelivr.net"],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: [],
      },
    },
  })
); // Use helmet to set security headers
app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cors());

// Make searchQuery available to all templates
app.use((req, res, next) => {
  res.locals.searchQuery = req.query.search || '';
  next();
});

// API Routes
app.use("/api", apiRoutes);

// --- Scan API Endpoints ---

// Endpoint to add an IP to the scan queue
app.post("/api/scan", (req, res) => {
    const { ip } = req.body;
    if (!ip) {
        return res.status(400).json({ success: false, message: "IP address is required." });
    }
    const result = queue.addToQueue(ip);
    res.status(result.success ? 202 : 409).json(result);
});

// Endpoint to check the status of a specific scan
app.get("/api/scan/status/:ip", (req, res) => {
    const { ip } = req.params;
    const status = queue.getStatus(ip);
    if (status) {
        res.json({ success: true, ip, ...status });
    } else {
        res.status(404).json({ success: false, message: "Scan status for this IP not found." });
    }
});

// Endpoint to view the entire queue and all statuses (for admin/debug)
app.get("/api/scan/status", (req, res) => {
    res.json({
        queue: queue.getQueue(),
        statuses: queue.getAllStatuses()
    });
});


// Page Routes
app.get("/", (req, res) => {
  res.render("index", { title: 'Home' }); // Renders views/index.ejs
});

app.get("/what-is-pasha", (req, res) => {
    const filePath = path.join(__dirname, 'en_what_is_pasha.md');
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error("Error reading markdown file:", err);
            return res.status(500).render('error', { message: 'Could not load content.' });
        }
        const htmlContent = md.render(data);
        res.render("what-is-pasha", {
            title: "What is Pasha?",
            description: "Turkey's First Native Internet Scanning and Analysis Platform",
            content: htmlContent
        });
    });
});

app.get("/who-are-we", (req, res) => {
    const filePath = path.join(__dirname, 'en_who_are_we.md');
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error("Error reading markdown file:", err);
            return res.status(500).render('error', { message: 'Could not load content.' });
        }
        const htmlContent = md.render(data);
        res.render("who-are-we", {
            title: "Who Are We?",
            description: "Meet the creator behind the Pasha project.",
            content: htmlContent
        });
    });
});

app.get("/getting-started", (req, res) => {
    res.render("getting-started", {
        title: "Getting Started",
        description: "Learn how to start using Pasha."
    });
});

const fetch = require('node-fetch');

/**
 * Validates an IPv4 address.
 * @param {string} ip The IP address to validate.
 * @returns {boolean} True if the IP is valid, false otherwise.
 */
function isValidIp(ip) {
    if (typeof ip !== 'string') {
        return false;
    }
    const parts = ip.split('.');
    if (parts.length !== 4) {
        return false;
    }
    for (const part of parts) {
        // Ensure part contains only digits and is not empty
        if (!/^\d+$/.test(part)) {
            return false;
        }
        // Check for leading zeros (e.g., "01")
        if (part.length > 1 && part.startsWith('0')) {
            return false;
        }
        const num = parseInt(part, 10);
        // Check if the number is within the valid 0-255 range
        if (isNaN(num) || num < 0 || num > 255) {
            return false;
        }
    }
    return true;
}

const { query, validationResult } = require('express-validator');

app.get("/search", 
  // Validate and sanitize the search query
  query('search').trim().escape(),
  async (req, res) => {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).render("error", { title: "Invalid Input", message: "Invalid characters in search query." });
    }

    try {
      const searchQuery = req.query.search || "";
      if (!searchQuery) {
        return res.redirect("/");
      }

      const page = req.query.page || 1;
      let apiURL;

      // If the query is a valid IP, construct a URL for an exact match.
      // Otherwise, construct a URL for a general text search.
      if (isValidIp(searchQuery)) {
        apiURL = `http://localhost:${port}/api/items?search=${encodeURIComponent(searchQuery)}&header=ip`;
      } else {
        apiURL = `http://localhost:${port}/api/items?search=${encodeURIComponent(searchQuery)}&page=${page}`;
      }

      const apiResponse = await fetch(apiURL);
      const data = await apiResponse.json();

      if (!data.success) {
          throw new Error(data.error || 'API request failed');
      }
      
      // If the original query was a valid IP and we found exactly one match, redirect.
      if (isValidIp(searchQuery) && data.data.length === 1) {
        return res.redirect(`/detail/${data.data[0]._id}`);
      }

      // For all other cases (non-IPs, or IPs with 0 or multiple results), render the search results page.
      const scanAvailable = data.data.length === 0;

      res.render("search-results", { 
          title: `Search for ${searchQuery}`,
          results: data.data,
          stats: data.stats,
          pagination: data.pagination,
          scanAvailable: scanAvailable, // Pass this to the template
          // Only show the scan button if the search was for a valid IP that was not found
          searchedIp: isValidIp(searchQuery) ? searchQuery : null 
      });
    } catch (err) {
      console.error("❌ Hata:", err.message);
      res.status(500).render("error", { title: "Error", message: err.message });
    }
});

app.get("/detail/:id", async (req, res) => {
    try {
        const itemId = req.params.id;
        const apiResponse = await fetch(`http://localhost:${port}/api/items/${itemId}`);
        const data = await apiResponse.json();

        if (!data.success) {
            throw new Error(data.error || 'API request failed');
        }

        res.render("port-details", {
            title: `Details for ${data.data.host || 'item'}`,
            item: data.data
        });
    } catch (err) {
        console.error("❌ Detail Page Error:", err.message);
        res.status(500).render("error", { title: "Error", message: err.message });
    }
});

const MarkdownIt = require('markdown-it');
const md = new MarkdownIt();
const fs = require('fs');

app.get("/tarassut", async (req, res) => {
    try {
        const apiResponse = await fetch(`http://localhost:${port}/api/tarassut/leaderboard`);
        const data = await apiResponse.json();

        if (!data.success) {
            throw new Error(data.error || 'API request failed');
        }

        res.render("tarassut", {
            title: "Tarassut Leaderboard",
            leaderboard: data.leaderboard,
            stats: data.stats,
            weeklyLeader: data.weeklyLeader,
            recentActivity: data.recentActivity,
            globalGoal: data.globalGoal
        });
    } catch (err) {
        console.error("❌ Tarassut Page Error:", err.message);
        res.status(500).render("error", { title: "Error", message: err.message });
    }
});

app.get("/privacy", (req, res) => {
    fs.readFile(path.join(__dirname, 'privacy_policy_english.md'), 'utf8', (err, data) => {
        if (err) {
            console.error("Error reading privacy policy:", err);
            return res.status(500).render('error', { title: 'Error', message: 'Could not load privacy policy.' });
        }
        const htmlContent = md.render(data);
        res.render("privacy", { title: 'Privacy Policy', content: htmlContent });
    });
});

// Not Found and Error Handling
app.use((req, res, next) => {
    res.status(404).render('404', { title: 'Not Found' });
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('error', { title: 'Server Error', message: 'Something went wrong on our end.' });
});


app.listen(port, () => {
  console.log(`🚀 Server http://localhost:${port} adresinde çalışıyor`);
});
