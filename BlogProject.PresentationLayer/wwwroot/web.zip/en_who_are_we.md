# About Me

## Hello, I'm the Creator of Pasha! 👋

First, let me introduce myself. I'm Hasan Yasin Yaşar, the person behind this project. I want to say "who we are" but I'm developing this entire system by myself.

---

## 🚀 My Story

### **Hasan Yasin Yaşar**
*Creator of Pasha*

![Profile Photo](/images/profile_image.jpg)

Hello! **I've been in the cybersecurity world since 2019** and this journey has been truly an incredible experience. In this adventure that I started at a young age, I've had **12 CVE records** so far - which makes me quite proud, honestly! 😊

#### 🏆 My CVE Achievements:
- **[CVE-2025-2301](https://www.cve.org/CVERecord?id=CVE-2025-2301)** - Online Exam Registration System
- **[CVE-2025-2404](https://www.cve.org/CVERecord?id=CVE-2025-2404)** - STOYS
- **[CVE-2025-2812](https://www.cve.org/CVERecord?id=CVE-2025-2812)** - Ticket Sales Automation
- **[CVE-2025-4686](https://www.cve.org/CVERecord?id=CVE-2025-4686)** - k12.Cafe Portal
- **[CVE-2025-4688](https://www.cve.org/CVERecord?id=CVE-2025-4688)** - SINAV.LİNK Exam Result Module
- **[CVE-2025-4784](https://www.cve.org/CVERecord?id=CVE-2025-4784)** - Tourtella
- **[CVE-2025-4822](https://www.cve.org/CVERecord?id=CVE-2025-4822)** - ScadaWatt Autopilot Solar Power Plant Automation
- **[CVE-2025-5319](https://www.cve.org/CVERecord?id=CVE-2025-5319)** - DIGITA Productivity Management System
- **[CVE-2025-5329](https://www.cve.org/CVERecord?id=CVE-2025-5329)** - Delta Course Automation
- **[CVE-2025-6830](https://www.cve.org/CVERecord?id=CVE-2025-6830)** - Xpoda Studio
- **[CVE-2025-6918](https://www.cve.org/CVERecord?id=CVE-2025-6918)** - PBX Virtual PBX Software
- **[CVE-2025-6919](https://www.cve.org/CVERecord?id=CVE-2025-6919)** - Aykome License Tracking System

## 💻 What Can I Do?

Over the years, I've developed myself in different areas. Here are the topics I think I'm capable of:

**Coding Side:**
- I build backend systems with **Node.js**, develop APIs
- **Python** is my favorite language - especially for creating cybersecurity tools
- I write fast scanning tools with **Go**, it's really great in terms of performance

**AI Work:**
- I perform threat analysis using ML algorithms
- I do database improvements and data enrichment using AI
- I develop anomaly detection systems
- I work on automatic classification of security vulnerabilities

**Red Team Activities:**
- I conduct penetration tests
- I design phishing campaigns (ethically, of course!)
- I perform network and web application testing

**Security Tool Development:**
- I write my own pentesting tools
- I develop vulnerability scanners
- I create network monitoring tools
- I write custom exploits

## 🤔 Why Did I Create Pasha?

Honestly, I was constantly using Shodan and one day I thought: "What if we had something like this too?" There was a serious gap in this field in Turkey and I said "Why not?"

Initially, it was just a personal project, but then I saw that this could really work. We especially needed a local solution to better analyze Turkey's internet infrastructure.

## 🎯 My Goals

**Short Term:**
- Make Pasha an indispensable tool for cybersecurity experts in Turkey
- Add more features and develop the platform
- Continuously improve user experience

**Long Term:**
- Make it competitive with Shodan and Censys in the international arena
- Make a real contribution to Turkey's cybersecurity ecosystem
- Maybe turn it into a big company someday (who knows! 😄)

## 😊 Personal Touch

The biggest reason I do this work is my passion. Since I've been dealing with this since 8th grade, it has become an inseparable part of my life.

I can't forget the excitement when I found CVEs. When I got my first CVE, I was so happy that I told everyone. Now I have 12 of them and I still experience the same excitement.

## 🤝 Let's Work Together!

If you also work in the cybersecurity field or are curious about this work, don't hesitate to contact me! We can do great projects together.

### How Can You Reach Me?
- **Email**: yasin@pasha.org.tr
- **[LinkedIn](https://www.linkedin.com/in/yasinyasarai/)**
- **[Github](https://github.com/sahici)**
- **[Instagram](https://instagram.com/yyasar.yasin)**

---

## 💭 Final Words

Pasha is not just a project, it's where my dreams come true. I'm doing my best for Turkey to have a say in the cybersecurity field.

I thank everyone who supported me on this journey. Let's work together for more success! 🚀

---

*"Sometimes small projects are the beginning of big changes. Pasha aims to be such a project."*