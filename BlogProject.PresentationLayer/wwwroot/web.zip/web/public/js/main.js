// Force Dark Theme - Override System Preferences
document.documentElement.style.colorScheme = 'dark';
document.documentElement.setAttribute('data-theme', 'dark');

// Override any system color scheme detection
if (window.matchMedia) {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: light)');
    if (mediaQuery.matches) {
        // Force dark theme even if system prefers light
        document.documentElement.style.colorScheme = 'dark';
        document.documentElement.setAttribute('data-theme', 'dark');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Navbar burger toggle
    const $navbarBurgers = Array.prototype.slice.call(document.querySelectorAll('.navbar-burger'), 0);
    if ($navbarBurgers.length > 0) {
        $navbarBurgers.forEach(el => {
            el.addEventListener('click', () => {
                const target = el.dataset.target;
                const $target = document.getElementById(target);
                el.classList.toggle('is-active');
                $target.classList.toggle('is-active');
            });
        });
    }

    // Scan functionality
    const startScanBtn = document.getElementById('start-scan-btn');
    const scanInitiator = document.getElementById('scan-initiator');
    const scanStatusContainer = document.getElementById('scan-status-container');
    const scanStatusMessage = document.getElementById('scan-status-message');

    if (startScanBtn) {
        startScanBtn.addEventListener('click', async () => {
            const ip = startScanBtn.dataset.ip;
            if (!ip) {
                scanStatusMessage.textContent = 'Error: No IP address specified.';
                scanStatusContainer.style.display = 'block';
                return;
            }

            // Hide the button and show the status container
            scanInitiator.style.display = 'none';
            scanStatusContainer.style.display = 'block';
            scanStatusMessage.textContent = 'Adding scan to the queue...';

            try {
                // 1. Add to queue
                const addResponse = await fetch('/api/scan', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ ip }),
                });

                const addResult = await addResponse.json();

                if (!addResult.success) {
                    scanStatusMessage.textContent = `Error: ${addResult.message}`;
                    scanStatusMessage.classList.remove('has-text-primary');
                    scanStatusMessage.classList.add('has-text-danger');
                    // Show the button again on failure to queue
                    scanInitiator.style.display = 'block';
                    return;
                }
                
                scanStatusMessage.textContent = 'Scan is in the queue. Waiting for it to start...';

                // 2. Poll for status
                pollStatus(ip);

            } catch (error) {
                console.error('Error starting scan:', error);
                scanStatusMessage.textContent = 'An unexpected error occurred. Please try again.';
                scanStatusMessage.classList.remove('has-text-primary');
                scanStatusMessage.classList.add('has-text-danger');
                scanInitiator.style.display = 'block';
            }
        });
    }
});

function pollStatus(ip) {
    const intervalId = setInterval(async () => {
        try {
            const statusResponse = await fetch(`/api/scan/status/${ip}`);
            if (!statusResponse.ok) {
                // Stop polling if the server returns a non-OK status like 404
                throw new Error(`Server returned status: ${statusResponse.status}`);
            }
            const statusResult = await statusResponse.json();
            
            const scanStatusMessage = document.getElementById('scan-status-message');

            switch (statusResult.status) {
                case 'queued':
                    scanStatusMessage.textContent = 'Scan is in the queue. Waiting for an available slot...';
                    break;
                case 'processing':
                    scanStatusMessage.textContent = 'Scan is in progress. This may take several minutes...';
                    break;
                case 'complete':
                    scanStatusMessage.textContent = 'Scan complete! Redirecting to results...';
                    clearInterval(intervalId); // Stop polling
                    window.location.href = statusResult.url; // Redirect the user
                    break;
                case 'error':
                    clearInterval(intervalId); // Stop polling on error

                    const scanStatusContainer = document.getElementById('scan-status-container');
                    const progressBar = scanStatusContainer.querySelector('progress');

                    // Hide the progress bar
                    if (progressBar) {
                        progressBar.style.display = 'none';
                    }

                    // Display the specific error message from the backend
                    scanStatusMessage.textContent = statusResult.error || 'An unknown error occurred.';
                    scanStatusMessage.classList.remove('has-text-primary');
                    scanStatusMessage.classList.add('has-text-danger');

                    // Create and append the "Back to Home" button if it doesn't exist
                    if (!scanStatusContainer.querySelector('a.button')) {
                        const homeButton = document.createElement('a');
                        homeButton.href = '/';
                        homeButton.className = 'button is-primary mt-4';
                        homeButton.innerHTML = '<span class="icon is-small"><i class="fas fa-home" aria-hidden="true"></i></span><span>Back to Home</span>';
                        scanStatusContainer.appendChild(homeButton);
                    }
                    break;
                default:
                    scanStatusMessage.textContent = `Unknown status: ${statusResult.status}`;
                    clearInterval(intervalId);
            }

        } catch (error) {
            console.error('Error polling for status:', error);
            const scanStatusMessage = document.getElementById('scan-status-message');
            scanStatusMessage.textContent = 'Error checking scan status. Polling stopped.';
            scanStatusMessage.classList.remove('has-text-primary');
            scanStatusMessage.classList.add('has-text-danger');
            clearInterval(intervalId); // Stop polling on critical error
        }
    }, 5000); // Poll every 5 seconds
}
